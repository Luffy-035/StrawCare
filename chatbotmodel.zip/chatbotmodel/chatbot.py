import asyncio
import os
import json
import numpy as np
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from PyCharacterAI import get_client
from PyCharacterAI.exceptions import SessionClosedError
from dotenv import load_dotenv
from groq import Groq
from fastembed import TextEmbedding

# Load environment variables
load_dotenv()
token = "8bffea7f61747077512e09269760e1db113b59e7"
character_id = "5pXTea64l3x-_I9n4saY01AXiCP6uGLITeRVX1fk94k"
GROQ_API_KEY = os.getenv("GROQ_API_KEY") or "your_groq_api_key_here"
SERIOUS_HEALTH_KEYWORDS = [
    # Cardiac/Cardiovascular
    "heart pain", "chest pain", "cardiac arrest", "heart attack", "myocardial infarction",
    "angina", "chest tightness", "heart palpitations", "irregular heartbeat", "cardiac arrhythmia",
    "chest pressure", "crushing chest pain", "radiating pain", "left arm pain with chest pain",
    "jaw pain with chest discomfort", "shortness of breath with chest pain",
    
    # Respiratory/Breathing
    "difficulty breathing", "shortness of breath", "cannot breathe", "gasping for air",
    "choking", "suffocating", "respiratory distress", "blue lips", "cyanosis",
    "wheezing severely", "pneumonia", "asthma attack", "respiratory failure",
    "pulmonary embolism", "collapsed lung", "pneumothorax",
    
    # Neurological
    "severe headache", "intense headache", "worst headache of life", "migraine severe",
    "sudden severe headache", "thunderclap headache", "stroke", "paralysis",
    "sudden weakness", "facial drooping", "slurred speech", "confusion",
    "loss of consciousness", "seizure", "convulsions", "fits", "epileptic attack",
    "dizziness severe", "fainting", "passing out", "unconscious", "not waking up",
    "memory loss sudden", "sudden blindness", "sudden hearing loss",
    
    # Gastrointestinal
    "severe abdominal pain", "intense stomach pain", "appendicitis", "peritonitis",
    "intestinal obstruction", "bowel obstruction", "severe nausea vomiting",
    "blood in vomit", "vomiting blood", "hematemesis", "severe diarrhea",
    "bloody stool", "rectal bleeding", "severe constipation", "abdominal distension",
    
    # Bleeding/Trauma
    "heavy bleeding", "uncontrolled bleeding", "hemorrhage", "severe bleeding",
    "bleeding that won't stop", "internal bleeding", "blood loss", "trauma",
    "severe injury", "broken bones", "fracture", "head injury", "concussion",
    "severe burns", "third degree burns", "electrical burns",
    
    # Poisoning/Overdose
    "poisoning", "overdose", "drug overdose", "accidental poisoning", "toxic ingestion",
    "chemical exposure", "carbon monoxide poisoning", "food poisoning severe",
    "allergic reaction severe", "anaphylaxis", "severe allergy", "swelling throat",
    
    # Psychiatric Emergencies
    "suicidal thoughts", "want to hurt myself", "planning suicide", "psychotic episode",
    "severe depression", "manic episode", "hallucinations", "hearing voices",
    "delusions", "paranoia severe", "panic attack severe", "anxiety attack severe",
    
    # Infectious/Fever
    "high fever", "fever over 103", "fever 104", "fever 105", "severe fever",
    "high fever and not improving", "fever with rash", "meningitis", "sepsis",
    "blood infection", "severe infection", "fever with stiff neck",
    
    # Gynecological/Obstetric
    "severe pelvic pain", "heavy menstrual bleeding", "pregnancy complications",
    "severe morning sickness", "preeclampsia", "ectopic pregnancy", "miscarriage",
    "severe cramping", "postpartum bleeding", "breast infection severe",
    
    # Urological
    "kidney stones severe", "unable to urinate", "blood in urine", "kidney pain severe",
    "urinary retention", "kidney infection severe", "bladder infection severe",
    
    # Orthopedic/Muscular
    "severe back pain", "cannot move", "severe joint pain", "muscle weakness severe",
    "severe neck pain", "spinal injury", "severe arthritis pain", "bone pain severe",
    
    # Endocrine/Metabolic
    "diabetic emergency", "blood sugar very high", "blood sugar very low",
    "diabetic ketoacidosis", "severe dehydration", "electrolyte imbalance",
    "thyroid storm", "adrenal crisis",
    
    # Eye/Vision
    "sudden vision loss", "eye injury severe", "chemical in eye", "severe eye pain",
    "flashing lights vision", "curtain over vision", "retinal detachment",
    
    # Ear/Hearing
    "severe ear pain", "ear infection severe", "sudden hearing loss", "ear bleeding",
    "severe tinnitus", "vertigo severe", "balance problems severe",
    
    # Skin/Dermatological
    "severe rash", "skin infection severe", "severe itching", "skin burning",
    "severe sunburn", "chemical burn", "severe eczema", "skin ulcer",
    
    # General Emergency Indicators
    "severe", "intense", "unbearable", "excruciating", "urgent", "emergency",
    "doctor immediately", "hospital now", "call ambulance", "life threatening",
    "critical condition", "deteriorating rapidly", "getting worse fast",
    "can't function", "debilitating", "incapacitating"
]

# Pydantic models for API
class PromptRequest(BaseModel):
    prompt: str

class Specialist(BaseModel):
    doctor_id: str
    name: str
    specialization: str
    category: str
    phone: str
    experience: int

class Analysis(BaseModel):
    detected_conditions: List[str]
    is_serious: bool
    recommended_specialty: str
    explanation: str

class ModelResponse(BaseModel):
    response: str
    analysis: Analysis
    specialists: Optional[List[Specialist]] = None
    is_serious: bool

# Core doctor retriever
class DoctorRetriever:
    def __init__(self, dataset_path="dataset.json"):
        self.embedding_model = TextEmbedding()
        with open(dataset_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)
        self.texts = []
        for d in self.data:
            availability = d.get("availability", "")
            if isinstance(availability, list):
                avail_str = " ".join([str(item) for item in availability if isinstance(item, str)])
            else:
                avail_str = str(availability)
            parts = [
                str(d.get("specialization", "")),
                str(d.get("category", "")),
                str(d.get("qualifications", "")),
                avail_str,
                str(d.get("name", ""))
            ]
            self.texts.append(" ".join(parts))
        self.embeddings = np.array(list(self.embedding_model.embed(self.texts)))
    def search(self, query, top_k=3):
        query_emb = np.array(list(self.embedding_model.embed([query]))[0])
        sims = np.dot(self.embeddings, query_emb) / (np.linalg.norm(self.embeddings, axis=1) * np.linalg.norm(query_emb) + 1e-8)
        best_idx = np.argpartition(sims, -top_k)[-top_k:]
        best_doctors = [self.data[i] for i in best_idx]
        return best_doctors

# Core message censor
class MessageCensor:
    def __init__(self, groq_client: Groq):
        self.groq_client = groq_client
        self.violation_indicators = [
            "kms", "kys", "kill myself", "kill yourself", "suicide", "suicidal",
            "self harm", "self-harm", "cut myself", "hurt myself", "end my life",
            "want to die", "wanna die", "better off dead", "take my own life",
            "harm myself", "overdose", "pills", "rope", "bridge", "jump off",
            "slit my wrists", "hang myself", "shoot myself", "stab myself",
            "worthless", "hopeless", "can't go on", "no point living"
        ]
    def needs_censoring(self, message: str) -> bool:
        message_lower = message.lower().strip()
        for indicator in self.violation_indicators:
            if indicator in message_lower:
                return True
        return False
    def censor_message(self, message: str) -> str:
        if not self.needs_censoring(message):
            return message
        censor_prompt = f"""
        You are a message paraphraser. Your job is to take a user message that might be filtered by Character.AI and rewrite it in a way that:
        1. PRESERVES the exact emotional content and meaning
        2. REMOVES explicit self-harm language that triggers AI filters
        3. KEEPS the same tone, urgency, and desperation if present
        4. MAINTAINS the user's actual feelings and mental state
        5. MAKES it conversational and natural for AI chat
        6. EXPRESSES the same pain/struggle without trigger words
        Examples of good paraphrasing:
        - "I want to kms" → "I'm feeling so hopeless and desperate right now"
        - "I should just kill myself" → "I feel like there's no way out of this pain"
        - "Maybe I should hurt myself" → "I'm having really dark thoughts and urges"
        - "I'm going to end it all" → "I feel like I can't handle this anymore and want everything to stop"
        - "I'm worthless and should die" → "I feel completely worthless and like I don't deserve to exist"
        Keep the emotional intensity but make it chat-safe. Don't minimize their feelings.
        Original message: "{message}"
        Provide only the paraphrased version, nothing else:"""
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": censor_prompt}],
                temperature=0.1,
                max_tokens=150
            )
            censored = response.choices[0].message.content.strip()
            if (censored.startswith('"') and censored.endswith('"')) or (censored.startswith("'") and censored.endswith("'")):
                censored = censored[1:-1]
            return censored
        except Exception:
            return self.basic_censor_fallback(message)
    def basic_censor_fallback(self, message: str) -> str:
        replacements = {
            "kms": "feel so hopeless",
            "kys": "you're really struggling",
            "kill myself": "feel like giving up",
            "kill yourself": "you're in so much pain",
            "suicide": "ending the pain",
            "suicidal": "having dark thoughts",
            "self harm": "hurting inside",
            "self-harm": "hurting inside",
            "end my life": "can't take this anymore",
            "want to die": "feel hopeless",
            "wanna die": "feel hopeless",
            "harm myself": "feel terrible inside",
            "hurt myself": "feel so much pain",
            "worthless": "feel like I don't matter",
            "no point living": "can't see any hope"
        }
        censored = message.lower()
        for original, replacement in replacements.items():
            censored = censored.replace(original, replacement)
        if message.isupper():
            return censored.upper()
        elif message.istitle():
            return censored.title()
        else:
            return censored

class EnhancedChatBot:
    def __init__(self, token: str, character_id: str, groq_api_key: str):
        self.token = token
        self.character_id = character_id
        self.groq_client = Groq(api_key=groq_api_key)
        self.censor = MessageCensor(self.groq_client)
        self.client = None
        self.chat = None
        self.me = None
        self.doctor_retriever = DoctorRetriever("dataset.json")

    async def chat_response(self, user_message: str):
        # Ensure CharacterAI session
        if self.client is None or self.me is None or self.chat is None:
            self.client = await get_client(token=self.token)
            self.me = await self.client.account.fetch_me()
            self.chat, _ = await self.client.chat.create_chat(self.character_id)

        # Step 1: Detect language and style (incl. Hinglish)
        language, is_hinglish, style = await self.detect_language_and_style(user_message)

        # Step 2: Translate to English if needed
        english_message = await self.translate_to_english(user_message)

        # Step 3: Extract illness/specialty (analysis logic)
        illness, specialties = await self.extract_illness_and_specialty(english_message)
        is_serious = False
        detected_conditions = []
        recommended_specialty = "None"
        explanation = ""
        specialists = None
        if illness:
            detected_conditions = [illness]
        else:
            detected_conditions = ["Non-specific symptoms"]
        lower_illness = (illness or "").lower()
        is_serious = any(keyword in lower_illness for keyword in SERIOUS_HEALTH_KEYWORDS)
        if is_serious:
            recommended_specialty = specialties[0] if specialties else "General Medicine"
            explanation = f"The user is experiencing {illness}, which is a symptom that can indicate a life-threatening condition such as a heart attack."
            rag_query = ", ".join(specialties) if specialties else illness
            doctors = self.doctor_retriever.search(rag_query, top_k=3)
            specialists = [
                Specialist(
                    doctor_id=str(doc.get("doctor_id", "")),
                    name=str(doc.get("name", "")),
                    specialization=str(doc.get("specialization", "")),
                    category=str(doc.get("category", "")),
                    phone=str(doc.get("phone", "")),
                    experience=int(doc.get("experience", 0))
                )
                for doc in doctors
            ] if doctors else None
        else:
            recommended_specialty = "None"
            explanation = "The query lacks specific symptoms or severity indicators to determine the need for specialist care."
            specialists = None

        # Step 4: Censor message if needed
        paraphrased_message = self.censor.censor_message(english_message)

        # Step 5: Call Character AI model and collect English response
        answer = await self.client.chat.send_message(
            self.character_id,
            self.chat.chat_id,
            paraphrased_message,
            streaming=True
        )
        full_response = ""
        async for r in answer:
            full_response = r.get_primary_candidate().text

        # Step 6: Translate model response back to user language/style
        if is_hinglish:
            user_final_response = await self.convert_to_hinglish(full_response, style)
        elif language.lower() != "english":
            user_final_response = await self.translate_from_english(language, full_response)
        else:
            user_final_response = full_response

        # Step 7: Build return object
        analysis_obj = Analysis(
            detected_conditions=detected_conditions,
            is_serious=is_serious,
            recommended_specialty=recommended_specialty,
            explanation=explanation
        )
        response_obj = ModelResponse(
            response=user_final_response,
            analysis=analysis_obj,
            specialists=specialists,
            is_serious=is_serious
        )
        return response_obj

    # Helper methods (unchanged pipeline)
    async def detect_language_and_style(self, user_message: str):
        prompt = f"""
        Analyze the following text and determine:
        1. The primary language/style being used
        2. Whether it's Hinglish (Hindi words written in English script mixed with English)
        Text: "{user_message}"
        Respond in JSON format:
        {{
            "language": "...",
            "is_hinglish": true/false,
            "style": "..."
        }}
        Examples:
        - "Hello kaise ho?" → {{"language": "Hinglish", "is_hinglish": true, "style": "Hindi-English mix"}}
        - "मैं ठीक हूँ" → {{"language": "Hindi", "is_hinglish": false, "style": "Pure Hindi"}}
        - "I am fine" → {{"language": "English", "is_hinglish": false, "style": "Pure English"}}
        Provide only the JSON, no extra text.
        """
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=50,
            )
            content = response.choices[0].message.content.strip()
            import json
            data = json.loads(content)
            return data.get("language", "English"), data.get("is_hinglish", False), data.get("style", "")
        except Exception:
            return "English", False, ""

    async def translate_to_english(self, user_message: str):
        prompt = f"""
        You are a multi-lingual assistant. Translate the following message to proper English.
        Handle Hinglish, Hindi, and other Indian languages appropriately.
        Input message: "{user_message}"
        Provide ONLY the English translation, nothing else.
        """
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=150,
            )
            translation = response.choices[0].message.content.strip()
            if (translation.startswith('"') and translation.endswith('"')) or (translation.startswith("'") and translation.endswith("'")):
                translation = translation[1:-1]
            return translation
        except Exception:
            return user_message

    async def convert_to_hinglish(self, english_response: str, user_style: str):
        prompt = f"""
        You are a Hinglish conversion expert. Convert the following English text to Hinglish style that matches the user's original style.
        User's original style: {user_style}
        English text to convert: "{english_response}"
        Hinglish conversion guidelines:
        - Mix Hindi words (written in English) with English naturally
        - Keep the conversational tone
        - Use common Hindi words like: kya, hai, nahi, acha, bas, etc.
        - Examples: "How are you?" → "Kaise ho?" or "Aap kaise hain?"
        - "I am fine" → "Main theek hun" or "I'm fine yaar"
        Provide ONLY the Hinglish conversion, nothing else.
        """
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500,
            )
            hinglish_text = response.choices[0].message.content.strip()
            if (hinglish_text.startswith('"') and hinglish_text.endswith('"')) or (hinglish_text.startswith("'") and hinglish_text.endswith("'")):
                hinglish_text = hinglish_text[1:-1]
            return hinglish_text
        except Exception:
            return english_response

    async def translate_from_english(self, original_lang: str, english_response: str):
        prompt = f"""
        You are a multi-lingual assistant. Translate the following English text to {original_lang} language.
        English text: "{english_response}"
        Provide ONLY the translated text, nothing else.
        """
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=500,
            )
            translation = response.choices[0].message.content.strip()
            if (translation.startswith('"') and translation.endswith('"')) or (translation.startswith("'") and translation.endswith("'")):
                translation = translation[1:-1]
            return translation
        except Exception:
            return english_response

    async def extract_illness_and_specialty(self, user_message: str):
        prompt = f"""
        You are a medical assistant. Given the user's message below, 
        1. Identify the main illness or symptoms described.
        2. List the doctor specialties appropriate for treating those symptoms.
        User message: "{user_message}"
        Respond in JSON format:
        {{
            "illness": "...",
            "specialties": ["..."] 
        }}
        Provide only the JSON, no extra text.
        """
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=100,
            )
            content = response.choices[0].message.content.strip()
            import json
            data = json.loads(content)
            illness = data.get("illness", "")
            specialties = data.get("specialties", [])
            return illness, specialties
        except Exception:
            return None, []

# FastAPI app definition
app = FastAPI()
bot_instance = None

@app.on_event("startup")
async def startup_event():
    global bot_instance
    if GROQ_API_KEY == "your_groq_api_key_here":
        raise RuntimeError("❌ ERROR: Please set your Groq API key in .env!")
    bot_instance = EnhancedChatBot(token, character_id, GROQ_API_KEY)
    await asyncio.sleep(0.01)

@app.post("/chat", response_model=ModelResponse)
async def chat_endpoint(prompt_request: PromptRequest):
    global bot_instance
    if bot_instance is None:
        raise HTTPException(status_code=500, detail="Model not initialized.")
    try:
        return await bot_instance.chat_response(prompt_request.prompt)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))